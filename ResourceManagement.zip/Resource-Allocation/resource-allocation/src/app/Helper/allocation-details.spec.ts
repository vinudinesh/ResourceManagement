import { AllocationDetails } from './allocation-details';

describe('AllocationDetails', () => {
  it('should create an instance', () => {
    expect(new AllocationDetails()).toBeTruthy();
  });
});
