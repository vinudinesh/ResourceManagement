import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { HttpClientModule, HttpClient, HttpRequest, HttpEventType, HttpResponse, HttpParams } from '@angular/common/http'
import { Observable } from 'rxjs';
import * as XLSX from 'xlsx';
import { NgForm } from '@angular/forms';
import { interval } from 'rxjs';
import { Router } from '@angular/router';
import { Data } from "../services/Data";
import { AllocationDetails } from '../Helper/allocation-details';
import { URLSearchParams } from 'url';
@Component({
  selector: 'app-allocation-details',
  templateUrl: './allocation-details.component.html',
  styleUrls: ['./allocation-details.component.css']
})
export class AllocationDetailsComponent implements OnInit {
  MyList: any;
  TempList : any;
  grade = [];
  programme = [];
  esaproject = [];
  ratecardrole = [];
  YesNo = [];
  SearchString:any="";
  SearchArray: any;
  p: number = 1;
  totalitems = 10;
  ApiPath = 'http://localhost:51709/api/';
  a: boolean = false;
  @ViewChild('TABLE') table: ElementRef;
  constructor(private httpService: HttpClient, private router: Router, private mydata: Data) {
  }

  ngOnInit() { 
    this.refreshData();
    this.httpService.get(this.ApiPath + 'Values').subscribe(
      data => {
        this.MyList = data as string[];
        this.TempList=this.MyList;
      }
    );  
  }

  refreshData() {
    this.httpService.get(this.ApiPath + 'MasterData').subscribe((response) => {
      this.grade = response["CognizantGrade"];
      this.programme = response["ProjectProgramme"];
      this.ratecardrole = response["RateCardRole"];
      this.esaproject = response["EsaPrjName"];
      this.YesNo = response["YesNo"];
    });
    this.httpService.get(this.ApiPath + 'Values').subscribe(
      data => {
        this.MyList = data as string[];
      }
    );
  }


  Result: any;
  FullData = {};
  selectedFile: File;
  UploadFile(event) {
    this.selectedFile = event.target.files[0];
    const uploadData = new FormData();
    uploadData.append('myFile', this.selectedFile, this.selectedFile.name);
    this.httpService.post(this.ApiPath + 'Values', uploadData).subscribe((response) => {
      this.Result = response;
    });
    
    this.refreshData();
  }
  viewRecord(Data) {
    this.FullData = Data;
  }
  updateRecord(UData) {
    this.mydata.updateData = UData;
    this.router.navigateByUrl('/UpdateFormComponent');
  }
  downloadFile() {
    let link = document.createElement("a");
    link.download = "Template";
    link.href = "./assets/ResourceListTemplate.xlsx";
    link.click();
  }
  resetinput(form: NgForm){
    form.resetForm();
  }
  SubmitData() {
    this.httpService.get(this.ApiPath + 'Data').subscribe((response) => {
      debugger;
      alert(response);
      if(response=="Data Inserted"){
      let link = document.getElementById("closepopup");
      link.click();
      }
    });
  }
  ExportTOExcel() {
    console.log("export");
    const ws: XLSX.WorkSheet=XLSX.utils.table_to_sheet(this.table.nativeElement);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

    XLSX.writeFile(wb, 'Rlg.xlsx');

  }
  SearchFunction() {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("myInput");
    this.SearchString = input.value.toUpperCase();
    if(this.SearchString==""){
      this.MyList=this.TempList;
      debugger;
    }
    else{
      let params=new HttpParams().set('SearchString',this.SearchString);
      this.httpService.get(this.ApiPath +'Search', {params:params}).subscribe(response => {
      this.MyList= response;
      debugger;
    });
    }
  }
}
