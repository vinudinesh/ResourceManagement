import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
  name: 'TableFilter'
})
export class SearchPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    if (!args) {
      return value;
    }
    return value.filter((val) => {
      let rVal = (val.Cognizant_ID.toLocaleLowerCase().includes(args)) || (val.Cognizant_Name.toLocaleLowerCase().includes(args));
      return rVal;
    })

  }

}