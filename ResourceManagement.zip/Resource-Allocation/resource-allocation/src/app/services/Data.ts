import { Injectable } from '@angular/core';
import { AllocationDetails } from '../Helper/allocation-details';
import { convertActionBinding } from '@angular/compiler/src/compiler_util/expression_converter';
@Injectable()
export class Data {

    public updateData: AllocationDetails = null;
    
    public constructor() {
     }
    

    

}