import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AllocationDetails } from '../Helper/allocation-details';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Data } from "../services/Data";
@Component({
  selector: 'app-update-form',
  templateUrl: './update-form.component.html',
  styleUrls: ['./update-form.component.css']
})
export class UpdateFormComponent implements OnInit {
  formData1: AllocationDetails;
  textBoxDisabled = true;
  isReadOnly: boolean = true;
  grade=[];
  programme=[];
  esaproject=[];
  ratecardrole=[];
  YesNo=[];
  ApiPath = 'http://localhost:51709/api/';
  status = [
    { id: 1, name: 'status1' },
    { id: 2, name: 'status2' },
    { id: 3, name: 'status3' },
    { id: 4, name: 'status4' }
  ];
  constructor(private httpService: HttpClient, private router: Router, private mydata: Data) {
    this.formData1 = {
      Cognizant_ID:0,
      Cognizant_Name: '',
      Cognizant_Grade: 0,
      Skill_Sets: '',
      Location: '',
      Cts_Line_Mgr: '',
      ESA_Prj_Name: 0,
      Bill_NBill: false,
      Rsrc_Alloc_End_Dt: new Date(),
      VI_End_Dt_Onshore: new Date(),
      VI_Type: '',
      VI_Ext_Posbl_Bynd_Enddt: false,
      VI_Hw_Lng_Can_Ext: '',
      VI_Ext_Posble_Frm_UK: 0,
      Resource_Name: '',
      Rate_Card_Role: 0,
      Rate_Card_Day_Rate: '',
      On_Off_2017: false,
      Project_Programme: 0,
      Portfolio_2017: '',
      Old_SOW: '',
      New_SOW_End_date: null,
      New_SOW: '',
      Billable: false,
      RLG_Account_Y_N: false,
      RLG_StaffID: 0,
      CTS_EL: '',
      RLG_ID: 123,
      RLG_Email: '',
      RLG_Join_Date: new Date(),
      RLG_Leaving_Date: new Date(),
      RLG_Rprt_Mgr: '',
      Asset_No_Onshore: '',
      VM_No_Offshore: '',
      Comments: '',
      Primary_Skill: '',
      status: ''
    }  
  }

  ngOnInit() {
    if (this.mydata.updateData != null) {
      this.formData1 = this.mydata.updateData;
    }
    this.httpService.get(this.ApiPath +'MasterData').subscribe((response) => {
    this.grade=response["CognizantGrade"];
    this.programme=response["ProjectProgramme"];
    this.ratecardrole=response["RateCardRole"];
    this.esaproject=response["EsaPrjName"];
    this.YesNo=response["YesNo"];
      debugger;
    });
  }
  toggle() {
    this.textBoxDisabled = !this.textBoxDisabled;
    if(this.textBoxDisabled==false){
      this.formData1.RLG_StaffID= 0;
      this.formData1.CTS_EL= '';
      this.formData1.RLG_ID= 0;
      this.formData1.RLG_Email= '';
      this.formData1.RLG_Join_Date= new Date();
      this.formData1.RLG_Leaving_Date=new Date();
      this.formData1.RLG_Rprt_Mgr= '';
      this.formData1.Asset_No_Onshore= '';
      this.formData1.VM_No_Offshore= '';
      this.formData1.Comments= '';
      this.formData1.Primary_Skill= '';
      this.formData1.status= '';
    }
  }
  onUpdate() {   
    this.httpService.put(this.ApiPath +'Values', this.formData1).subscribe(response => {
      debugger;
      console.log(response);
    });
    alert("success");
    this.router.navigateByUrl('/AllocationDetailsComponent');
  }
}
