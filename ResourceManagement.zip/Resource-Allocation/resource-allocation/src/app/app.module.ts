import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRouting } from './app.routing';
import { AppComponent } from './app.component';

import { AppHeaderComponent } from './common/header/app.header.component';
import { AppFooterComponent } from './common/footer/app.footer.component';
import { AppMenuComponent } from './common/menu/app.menu.component';

import { ViewBlocksComponent } from './blocks/view-blocks.component';
import { AllocationDetailsComponent } from './allocation-details/allocation-details.component';
import { UpdateDetailsComponent } from './update-details/update-details.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { HttpClientModule, HttpClient } from '@angular/common/http'
import {MatCardModule} from '@angular/material/card'
import {MatInputModule} from '@angular/material/input';
import { SearchPipe } from './allocation-details/serach.pipe';
import { Data } from "./services/Data";
import { UpdateFormComponent } from './update-form/update-form.component';
@NgModule({
  declarations: [  
    AppComponent,
    AppHeaderComponent,
    AppFooterComponent,
    AppMenuComponent,
    ViewBlocksComponent,
    AllocationDetailsComponent,
    UpdateDetailsComponent,
    SearchPipe,
    UpdateFormComponent
      
  ],
  imports: [
    NgxPaginationModule,
    HttpClientModule,  
    BrowserModule,
    FormsModule,
    AppRouting,
    MatCardModule,
    MatInputModule
  ],  
  providers: [
    Data
],
  bootstrap: [AppComponent]
})
export class AppModule {
 }
