import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AllocationDetails } from '../Helper/allocation-details';
import { HttpClient } from '@angular/common/http';
import {Router} from '@angular/router';
import { Data } from "../services/Data";
import { DatePipe, formatDate } from '@angular/common';
import { ConvertActionBindingResult } from '@angular/compiler/src/compiler_util/expression_converter';

@Component({
  selector: 'app-update-details',
  templateUrl: './update-details.component.html',
  styleUrls: ['./update-details.component.css']
})
export class UpdateDetailsComponent implements OnInit {

  formData1:AllocationDetails;
  UpdateDetails:AllocationDetails;
  textBoxDisabled = true;
  isReadOnly: boolean = true;
  grade=[];
  programme=[];
  esaproject=[];
  ratecardrole=[];
  YesNo=[];
  ApiPath = 'http://localhost:51709/api/';
  status = [
    { id: 1, name: 'status1' },
    { id: 2, name: 'status2' },
    { id: 3, name: 'status3' },
    { id: 4, name: 'status4' }
  ];


  datacheck:Boolean=false;
  constructor(private httpService: HttpClient,private router: Router,private mydata:Data) { 
  
  }
  formData: AllocationDetails;
  ngOnInit() {
    this.UpdateDetails=this.mydata.updateData;
    
    debugger;
    this.formData = {
      Cognizant_ID:0,
      Cognizant_Name: '',
      Cognizant_Grade: 0,
      Skill_Sets: '',
      Location: '',
      Cts_Line_Mgr: '',
      ESA_Prj_Name: 0,
      Bill_NBill: false,
      Rsrc_Alloc_End_Dt: new Date(),
      VI_End_Dt_Onshore: new Date(),
      VI_Type: '',
      VI_Ext_Posbl_Bynd_Enddt: false,
      VI_Hw_Lng_Can_Ext: '',
      VI_Ext_Posble_Frm_UK: 0,
      Resource_Name: '',
      Rate_Card_Role: 0,
      Rate_Card_Day_Rate: '',
      On_Off_2017: false,
      Project_Programme: 0,
      Portfolio_2017: '',
      Old_SOW: '',
      New_SOW_End_date: new Date('22/2/2019'),
      New_SOW: '',
      Billable: false,
      RLG_Account_Y_N: false,
      RLG_StaffID: 0,
      CTS_EL: '',
      RLG_ID: 0,
      RLG_Email: '',
      RLG_Join_Date: new Date(),
      RLG_Leaving_Date: new Date(),
      RLG_Rprt_Mgr: '',
      Asset_No_Onshore: '',
      VM_No_Offshore: '',
      Comments: '',
      Primary_Skill: '',
      status: ''
    }
    
  

    this.httpService.get(this.ApiPath +'MasterData').subscribe((response) => {
    this.grade=response["CognizantGrade"];
    this.programme=response["ProjectProgramme"];
    this.ratecardrole=response["RateCardRole"];
    this.esaproject=response["EsaPrjName"];
    this.YesNo=response["YesNo"];
  
      debugger;
    });

  }

  
  toggle() {
    this.textBoxDisabled = !this.textBoxDisabled;
  }

  onSubmit(form: NgForm) {
    //alert(this.formData.Rate_Card_Role);
    this.httpService.post(this.ApiPath +'MasterData', this.formData)
        .subscribe(response => {
          debugger;
          console.log(response);
        });
        alert("success");
        this.router.navigateByUrl('/AllocationDetailsComponent');
  }
}
