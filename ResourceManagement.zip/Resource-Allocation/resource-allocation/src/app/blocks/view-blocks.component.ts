import { Component } from '@angular/core';

@Component({
  selector: 'view-blocks',
  templateUrl: './view-blocks.component.html'
})
export class ViewBlocksComponent {
  blocks: any;
  status: string;

  constructor() {
    this.getBlocks();
  }

  getBlocks() {
     this.setStatus('Error getting blocks.')
  };

  setStatus = message => {
    this.status = message;
  };
}
