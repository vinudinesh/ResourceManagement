import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ViewBlocksComponent } from './blocks/view-blocks.component';
import { AllocationDetailsComponent } from './allocation-details/allocation-details.component';
import { UpdateDetailsComponent } from './update-details/update-details.component';
import { UpdateFormComponent } from './update-form/update-form.component';
const appRoutes: Routes = [
  { path: '', redirectTo: '/view-blocks', pathMatch: 'full' },
  { path: 'AllocationDetailsComponent', component: AllocationDetailsComponent },
  { path: 'UpdateDetailsComponent', component: UpdateDetailsComponent },
  { path: 'view-blocks', component: ViewBlocksComponent },
  {path:'UpdateFormComponent', component:UpdateFormComponent}
];

export const AppRouting: ModuleWithProviders = RouterModule.forRoot(appRoutes);