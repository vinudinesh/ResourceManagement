﻿using ResourceAllocationAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace ResourceAllocationAPI.Helper
{
    public class DataTableManipulation
    {
        public DataSet SetColumnsLikeDB(DataSet data)
        {
            string[] names = { "Cognizant_ID", "Cognizant_Name", "Cognizant_Grade", "Skill_Sets", "Location", "Cts_Line_Mgr", "ESA_Prj_Name", "Bill_NBill", "Rsrc_Alloc_End_Dt", "VI_End_Dt_Onshore", "VI_Type", "VI_Ext_Posbl_Bynd_Enddt", "VI_Hw_Lng_Can_Ext", "VI_Ext_Posble_Frm_UK", "Resource_Name", "Rate_Card_Role", "Rate_Card_Day_Rate", "On_Off_2017", "Project_Programme", "Portfolio_2017", "Old_SOW", "New_SOW_End_date", "New_SOW", "Billable", "RLG_Account_Y_N", "RLG_StaffID", "CTS_EL", "RLG_ID", "RLG_Email", "RLG_Join_Date", "RLG_Leaving_Date", "RLG_Rprt_Mgr", "Asset_No_Onshore", "VM_No_Offshore", "Comments", "Primary_Skill","Status" };
            for(int i = 0; i < names.Length; i++)
                data.Tables[0].Columns[i].ColumnName = names[i];  
            return data;
        }
    }
}