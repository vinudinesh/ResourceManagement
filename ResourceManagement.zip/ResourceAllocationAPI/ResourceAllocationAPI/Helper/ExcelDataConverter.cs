﻿using ExcelDataReader;
using Newtonsoft.Json;
using System;
using System.Data;
using System.IO;
using System.Web;

namespace ResourceAllocationAPI.Helper
{
    public class ExcelDataConverter : IExcelData
    {
        public DataTable Convert(HttpPostedFile UploadFile)
        {
            string temppath = Path.GetTempPath();
            var fileName = Path.GetFileName(UploadFile.FileName);
            string FilePath = Path.Combine(temppath, fileName);
            if (FilePath.EndsWith(".xlsx") || FilePath.EndsWith(".xls"))
            {
                UploadFile.SaveAs(FilePath); //storing uploaded file temporarily in client temporary directory
                FileStream stream = System.IO.File.Open(FilePath, FileMode.Open, FileAccess.Read);
                IExcelDataReader excelReader = null;
                if (FilePath.EndsWith(".xls"))
                    excelReader = ExcelReaderFactory.CreateBinaryReader(stream);
                if (FilePath.EndsWith(".xlsx"))
                    excelReader = ExcelReaderFactory.CreateOpenXmlReader(stream);

                DataSet Result;

                Result = excelReader.AsDataSet(new ExcelDataSetConfiguration()
                {
                    ConfigureDataTable = (_) => new ExcelDataTableConfiguration()
                    {
                        UseHeaderRow = true
                    }
                });
                stream.Close();
                DataTableManipulation data = new DataTableManipulation();
                Result = data.SetColumnsLikeDB(Result);
                excelReader.Close();
                DeleteFile(FilePath);
                return (Result.Tables[0]);
            }
            return new DataTable();
        }

        public void DeleteFile(string file)
        {
            if (File.Exists(file))
            {
                File.Delete(file);
            }
        }
    }
}