﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace ResourceAllocationAPI.Helper
{
    public class BulkDataInsert
    {
        public void Insert(DataTable data)
        {
            SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\AngularProjects\ResourceAllocationAPI\ResourceAllocationAPI\App_Data\ResourceAllocation.mdf;Integrated Security=True;MultipleActiveResultSets=True;Application Name=EntityFramework");
            SqlBulkCopy bulkCopy = new SqlBulkCopy(connection);
            bulkCopy.DestinationTableName = "AllocationData";
            foreach (DataColumn column in data.Columns)
                bulkCopy.ColumnMappings.Add(column.ColumnName, column.ColumnName);
            connection.Open();
            try
            {
                bulkCopy.WriteToServer(data);
            }
            catch(Exception e)
            {
                
            }
            
            connection.Close();
        }
        public DataTable ChangeType(DataTable RawData)
        {
            
            return RawData;
        }
    }
}