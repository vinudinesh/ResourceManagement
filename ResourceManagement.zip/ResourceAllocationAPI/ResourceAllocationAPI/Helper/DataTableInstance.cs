﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace ResourceAllocationAPI.Helper
{
    public static class DataTableInstance
    {
        static DataTable FullData=null;
        public static void SetDataTable(DataTable data)
        {
            FullData = data;
        }
        public static DataTable GetDataTable()
        {
            return FullData;
        }
    }
}