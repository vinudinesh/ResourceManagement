﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ResourceAllocationAPI.Models
{
    public class ListCollection
    {
        public List<string> CognizantGrade { get; set; }
        public List<string> EsaPrjName { get; set; }
        public List<string> RateCardRole { get; set; }
        public List<string> ProjectProgramme { get; set; }
        public List<string> YesNo { get; set; }
    }
}