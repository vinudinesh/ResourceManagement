﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ResourceAllocationAPI.Models
{
    public class DetailedRecords
    {
        public string Cognizant_ID { get; set; }
        public string Cognizant_Name { get; set; }
        public string Cognizant_Grade { get; set; }
        public string Skill_Sets { get; set; }
        public string Location { get; set; }
        public string Cts_Line_Mgr { get; set; }
        public string ESA_Prj_Name { get; set; }
        public string Bill_NBill { get; set; }
        public System.DateTime Rsrc_Alloc_End_Dt { get; set; }
        public Nullable<System.DateTime> VI_End_Dt_Onshore { get; set; }
        public string VI_Type { get; set; }
        public string VI_Ext_Posbl_Bynd_Enddt { get; set; }
        public string VI_Hw_Lng_Can_Ext { get; set; }
        public string VI_Ext_Posble_Frm_UK { get; set; }
        public string Resource_Name { get; set; }
        public string Rate_Card_Role { get; set; }
        public string Rate_Card_Day_Rate { get; set; }
        public string On_Off_2017 { get; set; }
        public string Project_Programme { get; set; }
        public string Portfolio_2017 { get; set; }
        public string Old_SOW { get; set; }
        public Nullable<System.DateTime> New_SOW_End_date { get; set; }
        public string New_SOW { get; set; }
        public string Billable { get; set; }
        public string RLG_Account_Y_N { get; set; }
        public string RLG_StaffID { get; set; }
        public string CTS_EL { get; set; }
        public string RLG_ID { get; set; }
        public string RLG_Email { get; set; }
        public Nullable<System.DateTime> RLG_Join_Date { get; set; }
        public Nullable<System.DateTime> RLG_Leaving_Date { get; set; }
        public string RLG_Rprt_Mgr { get; set; }
        public string Asset_No_Onshore { get; set; }
        public string VM_No_Offshore { get; set; }
        public string Comments { get; set; }
        public string Primary_Skill { get; set; }
        public string Status { get; set; }
    }
}