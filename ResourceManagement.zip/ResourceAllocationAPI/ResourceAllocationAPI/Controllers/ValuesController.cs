﻿using ResourceAllocationAPI.Helper;
using ResourceAllocationAPI.Models;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace ResourceAllocationAPI.Controllers
{
    public class ValuesController : ApiController
    {
        DataTable Result = null;
        ResourceAllocationEntities entities = new ResourceAllocationEntities();
        // GET api/values
        public IEnumerable<AllocationData> Get()
        {        
            List<AllocationData> Data = entities.AllocationDatas.ToList<AllocationData>();
            return Data;
        }

        public DataTable Post()
        {
            HttpFileCollection fileCollection = HttpContext.Current.Request.Files;
            HttpPostedFile UploadFile = fileCollection[0];
            ExcelDataConverter dataConverter = new ExcelDataConverter();
            Result = dataConverter.Convert(UploadFile);
            DataTableInstance.SetDataTable(Result);
            return Result;
        }

        // PUT api/values/5
        public void Put(AllocationData UData)
        {
            var entity = entities.AllocationDatas.Find(UData.Cognizant_ID);
            entities.Entry(entity).CurrentValues.SetValues(UData);
            entities.SaveChanges();
        }
    }
}
