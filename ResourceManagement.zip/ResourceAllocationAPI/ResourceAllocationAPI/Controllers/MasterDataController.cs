﻿using ResourceAllocationAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ResourceAllocationAPI.Controllers
{
    public class MasterDataController : ApiController
    {
        public ListCollection Get()
        {
            ResourceAllocationEntities entities = new ResourceAllocationEntities();
            List<string> esa = entities.Tbl_EsaPrj.Select(i => i.ESA_Prj_Name).AsEnumerable().ToList();
            List<string> grade = entities.Tbl_Grade.Select(i => i.Cognizant_Grade).AsEnumerable().ToList();
            List<string> rate = entities.Tbl_RateCardRole.Select(i => i.Rate_Card_Role).AsEnumerable().ToList();
            List<string> prj = entities.Tbl_PrjProg.Select(i => i.Project_Programme).AsEnumerable().ToList();
            List<string> yesno = entities.YesOrNoes.Select(i => i.YesNo).AsEnumerable().ToList();
            ListCollection coll = new ListCollection();
            coll.CognizantGrade = grade;
            coll.EsaPrjName = esa;
            coll.ProjectProgramme = prj;
            coll.RateCardRole = rate;
            coll.YesNo = yesno;
            return coll;
        }
        public string Post(AllocationData FormData)
        {
            using (ResourceAllocationEntities entities = new ResourceAllocationEntities())
            {
                try
                {
                    entities.AllocationDatas.Add(FormData);
                    entities.SaveChanges();
                }
                catch (Exception e)
                {
                    return e.Message;
                }

                return "success";
            }
        }
    }
}
