﻿using ResourceAllocationAPI.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity.SqlServer;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ResourceAllocationAPI.Controllers
{
    public class SearchController : ApiController
    {
        string Element = "";
        public IEnumerable<AllocationData> Get(string SearchString)
        {
            Element = SearchString;
            int a = Convert.ToInt32(Element);
            List<AllocationData> Data;
            using (var entities = new ResourceAllocationEntities())
            {
                string q = "select * from AllocationData where Cognizant_Id like '"+ Element + "%'";
                var SearchList = entities.AllocationDatas
                                    .SqlQuery(q)
                                    .ToList<AllocationData>();

                Data = SearchList;
            }
            return Data;
        }
    }
}
