﻿using ResourceAllocationAPI.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ResourceAllocationAPI.Controllers
{
    public class DataController : ApiController
    {
        private DataTable data=null;
        public string Get()
        {
            data = DataTableInstance.GetDataTable();
            BulkDataInsert BulkData = new BulkDataInsert();
            if (data != null)
            {
                BulkData.Insert(data);
                return "Data Inserted";
            }
            else
                return "Data Not Inserted";
        }
    }
}
